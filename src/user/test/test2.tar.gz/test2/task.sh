#!/bin/bash
sleep 10
echo "O hai dere2!" > result
