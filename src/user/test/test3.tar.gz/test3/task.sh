#!/bin/bash
sleep 10
echo "O hai dere3!" > result
