#!/bin/bash
sleep 10
echo "O hai dere 1!" > result
